# -*- coding: utf-8 -*-
"""
Photo Management Dialog - 写真管理ダイアログ（v1.9.1改訂）

Phase 3-A対応: 4列レイアウト + 拡大表示機能

レイアウト:
    [サムネイル] [修正前] [拡大表示] [修正後]
    
機能:
    - サムネイル列: 列名 + 小画像
    - 修正前/修正後: 画像 + アイコンツールバー
    - 拡大表示: hover時に大きく表示
"""

from typing import Optional, List, Dict
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QScrollArea, QWidget, QMessageBox, QFileDialog
)
from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.core import QgsFeature, QgsVectorLayer, QgsMessageLog, Qgis

# Phase 3-A新規ウィジェット
from ..photo.thumbnail_widget import ThumbnailWidget
from ..photo.photo_row_widget import PhotoRowWidget
from ..photo.zoom_panel import ZoomPanel


class PhotoManagementDialog(QDialog):
    """
    写真管理ダイアログ（Phase 3-A改訂版）
    
    使用例:
        dialog = PhotoManagementDialog(config_manager, data_manager, parent)
        dialog.set_layer(layer)
        dialog.set_feature(feature)
        dialog.show()
    
    レイアウト:
        ┌─────────────────────────────────────────────────────────────┐
        │ サムネイル │  修正前  │   拡大表示   │  修正後  │           │
        ├────────────┼──────────┼──────────────┼──────────┤           │
        │ 設備正面   │          │              │          │           │
        │  [写真1]   │ [画像1]  │   [拡大]     │ [画像1]  │           │
        │  80x60px   │ 200x150  │   400x300    │ 200x150  │           │
        │            │[🖊️][💾][🗑️]│   倍率2.0x   │[🖊️][💾][🗑️]│           │
        ├────────────┼──────────┼──────────────┼──────────┤           │
        │ 設備背面   │          │              │          │           │
        │  [写真2]   │ [画像2]  │              │ [画像2]  │           │
        │            │[🖊️][💾][🗑️]│              │[🖊️][💾][🗑️]│           │
        ├────────────┼──────────┼──────────────┼──────────┤           │
        │ 設備右正面 │          │              │          │           │
        │  [写真3]   │ [画像3]  │              │ [画像3]  │           │
        │            │[🖊️][💾][🗑️]│              │[🖊️][💾][🗑️]│           │
        └─────────────────────────────────────────────────────────────┘
    """
    
    closed = pyqtSignal()
    photo_saved = pyqtSignal(str, str)  # (field_name, relative_path)
    
    def __init__(self, config_manager, data_manager, parent=None):
        """
        初期化
        
        Args:
            config_manager: ConfigManager インスタンス
            data_manager: DataManager インスタンス
            parent: 親ウィジェット
        """
        super().__init__(parent)
        
        self._config_manager = config_manager
        self._data_manager = data_manager
        self._feature = None
        self._layer = None
        
        # ウィジェットリスト
        self._thumbnail_widgets: List[ThumbnailWidget] = []
        self._before_widgets: List[PhotoRowWidget] = []
        self._after_widgets: List[PhotoRowWidget] = []
        self._zoom_panel: Optional[ZoomPanel] = None
        
        # 写真ペア定義を取得
        self._photo_pairs = self._get_photo_pairs()
        
        # 移動・リサイズイベントの遅延タイマー
        self._save_timer = None
        
        self._setup_window()
        self._create_ui()
    
    def _setup_window(self):
        """ウィンドウ設定"""
        self.setWindowTitle("写真管理")
        self.setWindowFlags(
            Qt.Window |
            Qt.WindowCloseButtonHint |
            Qt.WindowMinimizeButtonHint
        )
        self.resize(1200, 800)
    
    def _create_ui(self):
        """
        UI作成（4列レイアウト）
        
        レイアウト:
            [ヘッダー]
            [グリッドレイアウト: サムネイル | 修正前 | 拡大 | 修正後]
            [閉じるボタン]
        """
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(16, 16, 16, 16)
        main_layout.setSpacing(12)
        
        # タイトル
        title_label = QLabel("写真管理", self)
        title_label.setStyleSheet("""
            QLabel {
                font-size: 14px;
                font-weight: bold;
                color: #333;
                padding-bottom: 8px;
                border-bottom: 2px solid #007AFF;
            }
        """)
        main_layout.addWidget(title_label)
        
        # スクロールエリア
        scroll_area = QScrollArea(self)
        scroll_area.setWidgetResizable(True)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        
        scroll_widget = QWidget()
        scroll_layout = QVBoxLayout(scroll_widget)
        
        # 4列グリッドレイアウト作成
        grid_layout = self._create_grid_layout()
        scroll_layout.addLayout(grid_layout)
        scroll_layout.addStretch()
        
        scroll_area.setWidget(scroll_widget)
        main_layout.addWidget(scroll_area)
        
        # ボタンエリア
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        
        close_button = QPushButton("閉じる", self)
        close_button.setStyleSheet("""
            QPushButton {
                background-color: #6c757d;
                color: white;
                border: none;
                padding: 8px 24px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover { background-color: #5a6268; }
            QPushButton:pressed { background-color: #545b62; }
        """)
        close_button.clicked.connect(self.close)
        button_layout.addWidget(close_button)
        
        main_layout.addLayout(button_layout)
    
    def _create_grid_layout(self) -> QGridLayout:
        """
        4列グリッドレイアウト作成
        
        Returns:
            QGridLayout: 4列レイアウト
        """
        layout = QGridLayout()
        layout.setSpacing(8)
        layout.setContentsMargins(8, 8, 8, 8)
        
        # ヘッダー行（row=0）
        header_style = """
            QLabel {
                font-weight: bold;
                font-size: 11pt;
                color: #495057;
                padding: 8px;
                background: #e9ecef;
                border-radius: 4px;
            }
        """
        
        header_thumbnail = QLabel("サムネイル")
        header_thumbnail.setAlignment(Qt.AlignCenter)
        header_thumbnail.setStyleSheet(header_style)
        layout.addWidget(header_thumbnail, 0, 0)
        
        header_before = QLabel("修正前")
        header_before.setAlignment(Qt.AlignCenter)
        header_before.setStyleSheet(header_style)
        layout.addWidget(header_before, 0, 1)
        
        header_zoom = QLabel("拡大表示")
        header_zoom.setAlignment(Qt.AlignCenter)
        header_zoom.setStyleSheet(header_style)
        layout.addWidget(header_zoom, 0, 2)
        
        header_after = QLabel("修正後")
        header_after.setAlignment(Qt.AlignCenter)
        header_after.setStyleSheet(header_style)
        layout.addWidget(header_after, 0, 3)
        
        # 拡大パネル（中央列、全行にまたがる）
        self._zoom_panel = ZoomPanel()
        row_count = len(self._photo_pairs)
        layout.addWidget(self._zoom_panel, 1, 2, row_count, 1)
        
        # 各写真行（row=1以降）
        for i, pair in enumerate(self._photo_pairs):
            row = i + 1
            
            display_name = pair["display_name"]
            before_field = pair["before"]
            after_field = pair["after"]
            
            # サムネイル列
            thumbnail = ThumbnailWidget(display_name)
            self._thumbnail_widgets.append(thumbnail)
            layout.addWidget(thumbnail, row, 0)
            
            # 修正前列
            before_widget = PhotoRowWidget("", "before")
            before_widget.hovered.connect(self._zoom_panel.show_image)
            before_widget.edit_clicked.connect(lambda idx=i: self._on_edit_clicked("before", idx))
            before_widget.save_clicked.connect(lambda idx=i: self._on_save_clicked("before", idx))
            before_widget.delete_clicked.connect(lambda idx=i: self._on_delete_clicked("before", idx))
            before_widget.replace_clicked.connect(lambda idx=i: self._on_replace_clicked("before", idx))
            self._before_widgets.append(before_widget)
            layout.addWidget(before_widget, row, 1)
            
            # 修正後列
            after_widget = PhotoRowWidget("", "after")
            after_widget.hovered.connect(self._zoom_panel.show_image)
            after_widget.edit_clicked.connect(lambda idx=i: self._on_edit_clicked("after", idx))
            after_widget.save_clicked.connect(lambda idx=i: self._on_save_clicked("after", idx))
            after_widget.delete_clicked.connect(lambda idx=i: self._on_delete_clicked("after", idx))
            after_widget.replace_clicked.connect(lambda idx=i: self._on_replace_clicked("after", idx))
            self._after_widgets.append(after_widget)
            layout.addWidget(after_widget, row, 3)
        
        return layout
    
    def _get_photo_pairs(self) -> List[Dict]:
        """
        写真ペアを取得
        
        Returns:
            list: [
                {
                    "before": "修正前写真URI_設備正面",
                    "after": "修正後写真URI_設備正面",
                    "display_name": "設備正面"
                },
                ...
            ]
        """
        # 設定ファイルから取得
        field_categories = self._config_manager.get("field_categories", {})
        photo_config = field_categories.get("photo", {})
        
        fields_before = photo_config.get("fields_before", [])
        fields_after = photo_config.get("fields_after", [])
        
        pairs = []
        for before, after in zip(fields_before, fields_after):
            display_name = self._generate_display_name(before)
            pairs.append({
                "before": before,
                "after": after,
                "display_name": display_name
            })
        
        return pairs
    
    def _generate_display_name(self, field_name: str) -> str:
        """
        フィールド名から表示名を生成
        
        例:
            "修正前写真URI_設備正面" → "設備正面"
            "設備写真1URI_修正前" → "設備写真1URI"
        
        Args:
            field_name: フィールド名
        
        Returns:
            str: 表示名
        """
        # "_" で分割して最後の部分を取得
        parts = field_name.split('_')
        if len(parts) > 1:
            return parts[-1]
        
        # フォールバック: "_修正前" を削除
        return field_name.replace('_修正前', '')
    
    def set_layer(self, layer: QgsVectorLayer):
        """
        レイヤをセット
        
        Args:
            layer: 対象レイヤ
        """
        self._layer = layer
        
        QgsMessageLog.logMessage(
            f"PhotoManagementDialog - レイヤ設定完了: {layer.name() if layer else 'None'}",
            "PoleFacility", Qgis.Info
        )
    
    def set_feature(self, feature: QgsFeature):
        """
        地物をセット
        
        Args:
            feature: 地物オブジェクト
        """
        try:
            self._feature = feature
            
            if not feature or not feature.isValid():
                QgsMessageLog.logMessage(
                    "PhotoManagementDialog - 無効な地物が指定されました",
                    "PoleFacility", Qgis.Warning
                )
                return
            
            # 各ウィジェットに写真をセット
            for i, pair in enumerate(self._photo_pairs):
                before_field = pair["before"]
                after_field = pair["after"]
                
                # 修正前画像パスを取得
                before_path = feature[before_field] if before_field in feature.fields().names() else ""
                after_path = feature[after_field] if after_field in feature.fields().names() else ""
                
                # サムネイルに設定（修正前画像を使用）
                if i < len(self._thumbnail_widgets):
                    self._thumbnail_widgets[i].set_image(before_path)
                
                # 修正前ウィジェットに設定
                if i < len(self._before_widgets):
                    self._before_widgets[i].set_image(before_path)
                
                # 修正後ウィジェットに設定
                if i < len(self._after_widgets):
                    self._after_widgets[i].set_image(after_path)
            
            # タイトル更新
            self._update_title()
            
            QgsMessageLog.logMessage(
                f"PhotoManagementDialog - 地物設定完了: feature_id={feature.id()}",
                "PoleFacility", Qgis.Info
            )
            
        except Exception as e:
            QgsMessageLog.logMessage(
                f"PhotoManagementDialog - set_feature エラー: {str(e)}",
                "PoleFacility", Qgis.Critical
            )
    
    def _update_title(self):
        """ウィンドウタイトルを更新"""
        if not self._feature:
            return
        
        try:
            equipment_number = self._feature["設備番号"] if "設備番号" in self._feature.fields().names() else ""
            
            if equipment_number:
                self.setWindowTitle(f"写真管理 - 設備番号: {equipment_number}")
            else:
                self.setWindowTitle("写真管理")
        
        except Exception as e:
            QgsMessageLog.logMessage(
                f"PhotoManagementDialog - タイトル更新エラー: {str(e)}",
                "PoleFacility", Qgis.Warning
            )
            self.setWindowTitle("写真管理")
    
    def _on_edit_clicked(self, photo_type: str, index: int):
        """編集ボタンクリック時"""
        QMessageBox.information(self, "編集", f"{photo_type} {index+1}の編集機能は今後実装予定です")
    
    def _on_save_clicked(self, photo_type: str, index: int):
        """保存ボタンクリック時"""
        QMessageBox.information(self, "保存", f"{photo_type} {index+1}の保存機能は今後実装予定です")
    
    def _on_delete_clicked(self, photo_type: str, index: int):
        """削除ボタンクリック時"""
        reply = QMessageBox.question(
            self,
            "確認",
            f"{photo_type} {index+1}の編集内容を削除しますか?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            QMessageBox.information(self, "削除", "削除機能は今後実装予定です")
    
    def _on_replace_clicked(self, photo_type: str, index: int):
        """
        元画像差し替えボタンクリック時（Task 6）
        
        Args:
            photo_type: "before" or "after"
            index: 写真インデックス
        """
        filepath, _ = QFileDialog.getOpenFileName(
            self,
            "画像ファイルを選択",
            "",
            "画像ファイル (*.jpg *.jpeg *.png);;すべてのファイル (*)"
        )
        
        if not filepath:
            return
        
        try:
            # 画像を読み込んで更新
            if photo_type == "before" and index < len(self._before_widgets):
                self._before_widgets[index].set_image(filepath)
                # サムネイルも更新
                if index < len(self._thumbnail_widgets):
                    self._thumbnail_widgets[index].set_image(filepath)
            elif photo_type == "after" and index < len(self._after_widgets):
                self._after_widgets[index].set_image(filepath)
            
            # 地物の属性を更新
            if self._layer and self._feature:
                pair = self._photo_pairs[index]
                field_name = pair["before"] if photo_type == "before" else pair["after"]
                
                self._layer.startEditing()
                self._layer.changeAttributeValue(
                    self._feature.id(),
                    self._layer.fields().indexFromName(field_name),
                    filepath
                )
                self._layer.commitChanges()
                
                # ExportTracker にマーク
                from ..utils.export_tracker import ExportTracker
                ExportTracker.get_instance().mark_modified()
                
                QgsMessageLog.logMessage(
                    f"PhotoManagementDialog - 画像差し替え完了: {field_name} → {filepath}",
                    "PoleFacility", Qgis.Info
                )
        
        except Exception as e:
            QgsMessageLog.logMessage(
                f"PhotoManagementDialog - 画像差し替えエラー: {str(e)}",
                "PoleFacility", Qgis.Critical
            )
            QMessageBox.critical(self, "エラー", f"画像の差し替えに失敗しました:\n{str(e)}")
    
    def refresh(self):
        """表示を更新"""
        if self._feature:
            self.set_feature(self._feature)
    
    def closeEvent(self, event):
        """クローズイベント"""
        QgsMessageLog.logMessage(
            "PhotoManagementDialog - ダイアログを閉じます",
            "PoleFacility", Qgis.Info
        )
        
        self.closed.emit()
        super().closeEvent(event)
    
    def moveEvent(self, event):
        """ウィンドウ移動イベント"""
        super().moveEvent(event)
        self._schedule_save_position()
    
    def resizeEvent(self, event):
        """ウィンドウリサイズイベント"""
        super().resizeEvent(event)
        self._schedule_save_position()
    
    def _schedule_save_position(self):
        """座標保存をスケジュール"""
        from PyQt5.QtCore import QTimer
        
        if self._save_timer is not None:
            self._save_timer.stop()
            self._save_timer.deleteLater()
        
        self._save_timer = QTimer(self)
        self._save_timer.setSingleShot(True)
        self._save_timer.timeout.connect(self._save_current_position)
        self._save_timer.start(500)
    
    def _save_current_position(self):
        """現在のウィンドウ位置・サイズを保存"""
        from PyQt5.QtWidgets import QApplication
        
        if self._config_manager is None:
            return
        
        try:
            screen = QApplication.desktop().screenNumber(self)
            pos = self.pos()
            size = self.size()
            
            self._config_manager.save_window_position(
                'photo', screen, pos.x(), pos.y(), size.width(), size.height()
            )
        except Exception:
            pass
