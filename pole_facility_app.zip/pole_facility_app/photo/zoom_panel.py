# -*- coding: utf-8 -*-
"""
Zoom Panel - 拡大表示パネル

hover中の画像を拡大表示するパネル。
常にビュー内にフィット（スクロールなし）。
"""

from typing import Optional
from qgis.PyQt.QtWidgets import QWidget, QVBoxLayout, QLabel
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QPixmap
from qgis.core import QgsMessageLog, Qgis


class ZoomPanel(QWidget):
    """
    拡大表示パネル
    
    機能:
        - hover中の画像を拡大表示（400x300にフィット）
        - 倍率を表示（例: 倍率2.5x）
        - 常にビュー内にフィット（スクロールなし）
    
    使用例:
        panel = ZoomPanel()
        photo_widget.hovered.connect(panel.show_image)
    """
    
    def __init__(self, parent=None):
        """初期化"""
        super().__init__(parent)
        
        self._current_image_path = ""
        self._title_label = None
        self._image_label = None
        self._zoom_label = None
        
        self._create_ui()
    
    def _create_ui(self):
        """UI作成"""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)
        
        # パネルスタイル
        self.setStyleSheet("""
            QWidget {
                background-color: #f8f9fa;
                border: 2px solid #dee2e6;
                border-radius: 4px;
            }
        """)
        
        # タイトル
        self._title_label = QLabel("拡大表示", self)
        self._title_label.setAlignment(Qt.AlignCenter)
        self._title_label.setStyleSheet("""
            QLabel {
                font-weight: bold;
                font-size: 11pt;
                color: #495057;
                background: transparent;
                border: none;
                padding: 4px;
            }
        """)
        layout.addWidget(self._title_label)
        
        # 画像表示エリア（400x300px）
        self._image_label = QLabel(self)
        self._image_label.setAlignment(Qt.AlignCenter)
        self._image_label.setFixedSize(400, 300)
        self._image_label.setStyleSheet("""
            QLabel {
                background: white;
                border: 1px solid #ced4da;
                border-radius: 2px;
            }
        """)
        self._image_label.setText("hover時に画像を表示")
        layout.addWidget(self._image_label, alignment=Qt.AlignCenter)
        
        # 倍率表示
        self._zoom_label = QLabel("", self)
        self._zoom_label.setAlignment(Qt.AlignCenter)
        self._zoom_label.setStyleSheet("""
            QLabel {
                font-size: 9pt;
                color: #6c757d;
                background: transparent;
                border: none;
                padding: 4px;
            }
        """)
        layout.addWidget(self._zoom_label)
        
        layout.addStretch()
    
    def show_image(self, image_path: str):
        """
        画像を拡大表示
        
        Args:
            image_path: 画像パス（空文字で非表示）
        """
        if not image_path:
            self.clear()
            return
        
        self._current_image_path = image_path
        
        try:
            pixmap = QPixmap(image_path)
            
            if pixmap.isNull():
                self.clear()
                return
            
            # 400x300にフィット、倍率計算
            scaled, zoom_factor = self._calculate_zoom_size(pixmap)
            
            self._image_label.setPixmap(scaled)
            self._image_label.setText("")
            
            # 倍率表示
            self._zoom_label.setText(f"倍率: {zoom_factor:.1f}x")
            
        except Exception as e:
            QgsMessageLog.logMessage(
                f"ZoomPanel - 画像読み込みエラー: {str(e)}",
                "PoleFacility", Qgis.Warning
            )
            self.clear()
    
    def _calculate_zoom_size(self, pixmap: QPixmap) -> tuple:
        """
        拡大表示サイズを計算（400x300にフィット）
        
        Args:
            pixmap: 元画像
        
        Returns:
            tuple: (スケーリングされた画像, 倍率)
        """
        max_width = 400
        max_height = 300
        
        original_width = pixmap.width()
        original_height = pixmap.height()
        
        # スケール計算
        scale = min(
            max_width / original_width,
            max_height / original_height
        )
        
        # スケーリング
        scaled = pixmap.scaled(
            max_width, max_height,
            Qt.KeepAspectRatio,
            Qt.SmoothTransformation
        )
        
        return (scaled, scale)
    
    def clear(self):
        """表示をクリア"""
        self._current_image_path = ""
        self._image_label.setPixmap(QPixmap())
        self._image_label.setText("hover時に画像を表示")
        self._zoom_label.setText("")
    
    def get_current_image_path(self) -> str:
        """現在表示中の画像パスを取得"""
        return self._current_image_path
